#!/bin/sh

#               IMPORTANT
# The ordering of certain items on the CLASSPATH is significant.
# Do not move any of the CLASSPATH entries below.

cd `dirname $0`

CLASSPATH=.
CLASSPATH=$CLASSPATH:./lib/LTS.jar
CLASSPATH=$CLASSPATH:./lib/esps_validator.jar
CLASSPATH=$CLASSPATH:./lib/GSLSchematronValidator.jar
CLASSPATH=$CLASSPATH:./lib/xmlsec-1.4.1.jar
CLASSPATH=$CLASSPATH:./lib/jce-jdk13-114.jar
CLASSPATH=$CLASSPATH:./lib/xalan_enhanced.jar
CLASSPATH=$CLASSPATH:./lib/esps_exslt.jar
CLASSPATH=$CLASSPATH:./lib/esps_j2ee.jar
CLASSPATH=$CLASSPATH:./lib/jetty-6.1.3.jar
CLASSPATH=$CLASSPATH:./lib/jetty-util-6.1.3.jar
CLASSPATH=$CLASSPATH:./lib/commons-fileupload-1.1.1.jar
CLASSPATH=$CLASSPATH:./lib/commons-io-1.3.1.jar
CLASSPATH=$CLASSPATH:./lib/commons-logging.jar
CLASSPATH=$CLASSPATH:./lib/commons-logging-api.jar

CLASSPATH=$CLASSPATH:./lib/jdom.jar
CLASSPATH=$CLASSPATH:./lib/joda-time-1.4.jar
CLASSPATH=$CLASSPATH:./lib/xercesImpl.jar
CLASSPATH=$CLASSPATH:./lib/antlr_2.7.6.1.jar
CLASSPATH=$CLASSPATH:./lib/tools.jar
CLASSPATH=$CLASSPATH:./lib/velocity-dep-1.4.jar

CLASSPATH=$CLASSPATH:./lib/core-3.1.1.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.jdt.core_3.2.3.v_686_R32x.jar

CLASSPATH=$CLASSPATH:./lib/commons-collections.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.common_2.3.0.v200706262000.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.ecore.xmi_2.3.0.v200706262000.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.ecore_2.3.0.v200706262000.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.equinox.common_3.3.0.v20070426.jar
CLASSPATH=$CLASSPATH:./lib/picocontainer-1.2.jar
CLASSPATH=$CLASSPATH:./lib/SACalc.jar
CLASSPATH=$CLASSPATH:./lib/xsd_2.2.3.v200705141058.jar

JAVA_OPTIONS=-Dresponder.config.generateEnvelope=true
JAVA_OPTIONS="$JAVA_OPTIONS -Dresponder.config.xsltStylesheet=Webapp/resources/stylesheets/ValidationResponse.xsl"
JAVA_OPTIONS="$JAVA_OPTIONS -Dlts.config=resources/config/UserConfigurable/LTSConfig.xml"
JAVA_OPTIONS="$JAVA_OPTIONS -Dvalidator.config=resources/config/NonConfigurable/validatorConfig.xml"
JAVA_OPTIONS="$JAVA_OPTIONS -Dlts.root=$LTS_HOME"

java -cp $CLASSPATH $JAVA_OPTIONS uk.gov.hmrc.aspire.lts.test.LTSStandalone

echo Application terminated.
echo Press [Return] to exit . . .
read ignoreInput

exit 0