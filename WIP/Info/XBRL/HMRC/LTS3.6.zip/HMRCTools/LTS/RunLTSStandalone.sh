#!/bin/sh

#               IMPORTANT
# The ordering of certain items on the CLASSPATH is significant.
# Do not move any of the CLASSPATH entries below.

cd `dirname $0`

CLASSPATH=.
CLASSPATH=$CLASSPATH:./lib/jetty-6.1.9.jar
CLASSPATH=$CLASSPATH:./lib/jetty-util-6.1.9.jar
CLASSPATH=$CLASSPATH:./lib/servlet-api-2.5-6.1.9.jar

CLASSPATH=$CLASSPATH:./lib/jsp-2.1.jar

CLASSPATH=$CLASSPATH:./lib/activation-1.1.jar
CLASSPATH=$CLASSPATH:./lib/annogen-0.1.0.jar
CLASSPATH=$CLASSPATH:./lib/axiom-api-1.2.7.jar
CLASSPATH=$CLASSPATH:./lib/axiom-dom-1.2.7.jar
CLASSPATH=$CLASSPATH:./lib/axiom-impl-1.2.7.jar
CLASSPATH=$CLASSPATH:./lib/axis2-adb-1.4.jar
CLASSPATH=$CLASSPATH:./lib/axis2-adb-codegen-1.4.jar
CLASSPATH=$CLASSPATH:./lib/axis2-codegen-1.4.jar
CLASSPATH=$CLASSPATH:./lib/axis2-java2wsdl-1.4.jar
CLASSPATH=$CLASSPATH:./lib/axis2-jaxws-1.4.jar
CLASSPATH=$CLASSPATH:./lib/axis2-kernel-1.4-PATCHED.jar
CLASSPATH=$CLASSPATH:./lib/axis2-saaj-1.4.jar
CLASSPATH=$CLASSPATH:./lib/backport-util-concurrent-3.1.jar
CLASSPATH=$CLASSPATH:./lib/commons-codec-1.3.jar
CLASSPATH=$CLASSPATH:./lib/commons-fileupload-1.2.jar
CLASSPATH=$CLASSPATH:./lib/commons-httpclient-3.1.jar
CLASSPATH=$CLASSPATH:./lib/commons-io-1.4.jar
CLASSPATH=$CLASSPATH:./lib/commons-logging-1.1.1.jar
CLASSPATH=$CLASSPATH:./lib/mail-1-4.jar
CLASSPATH=$CLASSPATH:./lib/neethi-2.0.4.jar
CLASSPATH=$CLASSPATH:./lib/soapmonitor-1.4.jar
CLASSPATH=$CLASSPATH:./lib/woden-impl-dom-1.0M8.jar
CLASSPATH=$CLASSPATH:./lib/woden-api-1.0M8.jar
CLASSPATH=$CLASSPATH:./lib/wsdl4j-1.6.2.jar
CLASSPATH=$CLASSPATH:./lib/wstx-asl-3.2.4.jar
CLASSPATH=$CLASSPATH:./lib/xml-apis-1.3.04.jar
CLASSPATH=$CLASSPATH:./lib/XmlSchema-1.4.2.jar

CLASSPATH=$CLASSPATH:./lib/antlr_2.7.6.1.jar
CLASSPATH=$CLASSPATH:./lib/core-3.1.1.jar
CLASSPATH=$CLASSPATH:./lib/GSLSchematronValidator.jar
CLASSPATH=$CLASSPATH:./lib/jdom.jar
CLASSPATH=$CLASSPATH:./lib/velocity-dep-1.4.jar
CLASSPATH=$CLASSPATH:./lib/xercesImpl-2.9.1.jar

CLASSPATH=$CLASSPATH:./lib/commons-collections.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.common_2.4.0.v200808251517.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.ecore.xmi_2.4.1.v200808251517.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.emf.ecore_2.4.1.v200808251517.jar
CLASSPATH=$CLASSPATH:./lib/org.eclipse.equinox.common_3.4.0.v20080421-2006.jar
CLASSPATH=$CLASSPATH:./lib/picocontainer-1.2.jar
CLASSPATH=$CLASSPATH:./lib/Calc.jar
CLASSPATH=$CLASSPATH:./lib/serializer.jar
CLASSPATH=$CLASSPATH:./lib/xmlunit-1.1.jar
CLASSPATH=$CLASSPATH:./lib/xsd_2.2.3.v200705141058.jar

CLASSPATH=$CLASSPATH:./lib/esps_validator.jar

CLASSPATH=$CLASSPATH:./lib/Utilities.jar

CLASSPATH=$CLASSPATH:./lib/LTS.jar
CLASSPATH=$CLASSPATH:./lib/LTSInjector.jar

CLASSPATH=$CLASSPATH:./lib/tools.jar
CLASSPATH=$CLASSPATH:./lib/javaee-1.5.jar

CLASSPATH=$CLASSPATH:./lib/xmlsec-1.4.1.jar
CLASSPATH=$CLASSPATH:./lib/jce-jdk13-114.jar
CLASSPATH=$CLASSPATH:./lib/xalan_enhanced.jar

JAVA_OPTIONS=-Dresponder.config.generateEnvelope=true
JAVA_OPTIONS="$JAVA_OPTIONS -Dresponder.config.xsltStylesheet=Webapp/resources/stylesheets/ValidationResponse.xsl"
JAVA_OPTIONS="$JAVA_OPTIONS -Dlts.config=resources/config/UserConfigurable/LTSConfig.xml"
JAVA_OPTIONS="$JAVA_OPTIONS -Dvalidator.config=resources/config/NonConfigurable/validatorConfig.xml"
JAVA_OPTIONS="$JAVA_OPTIONS -Dlts.root=$LTS_HOME"

java -cp $CLASSPATH $JAVA_OPTIONS uk.gov.hmrc.aspire.lts.test.LTSStandalone

echo Application terminated.
echo Press [Return] to exit . . .
read ignoreInput

exit 0